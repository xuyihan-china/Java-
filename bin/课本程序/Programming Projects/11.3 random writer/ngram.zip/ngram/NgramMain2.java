import java.util.*;
import java.io.*;

public class NgramMain2 {
    public static final int LINE_BREAK = 65;

    public static void main(String[] args) throws FileNotFoundException {
        System.out.println("Welcome to the CSE143 Ngram Solver.  You specify");
        System.out.println("the file to sample, the ngram size, and the");
        System.out.println("desired number of characters of output.");
        System.out.println();

        // open the text file
        Scanner console = new Scanner(System.in);
        System.out.print("What is the name of the text file? ");
        Scanner input = new Scanner(new File(console.nextLine()));
        StringBuilder text = new StringBuilder(input.next());
        while (input.hasNext())
            text.append(" " + input.next());

        // construct solver object
        System.out.print("What value of n do you want to use? ");
        int n = console.nextInt();
        NgramSolver2 solver = new NgramSolver2(n, text.toString());

        // produce random output
        System.out.print("How many characters of output do you want? ");
        int length = console.nextInt();
        System.out.println();
        generateText(solver, length);
    }

    public static void generateText(NgramSolver2 solver, int length) {
        String current = "";
        int column = 0;
        int total = 0;
        boolean done = false;
        while (!done) {
            if (solver.contains(current)) {
                char next = solver.randomChar(current);
                if (next == ' ' && column >= LINE_BREAK) {
                    System.out.println();
                    column = 0;
                } else {
                    System.out.print(next);
                    column++;
                }
		current = (current + next).substring(1);
                total++;
                if (total >= length && next == '.')
                    done = true;
            } else {
                current = solver.randomStart();
                System.out.print(current);
                column += current.length();
                total += current.length();
                if (total >= length && current.endsWith("."))
                    done = true;
            }
        }
        System.out.println();
    }
}