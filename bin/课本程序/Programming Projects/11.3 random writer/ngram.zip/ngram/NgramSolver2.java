import java.util.*;

public class NgramSolver2 {
    private Map<String, List<Character>> frequencies;
    private List<String> starts;
    private Random r;

    public NgramSolver2(int n, String text) {
        if (n < 0 || n > text.length())
            throw new IllegalArgumentException("illegal n");
        else if (text.indexOf(".") < 0 && text.indexOf("?") < 0 &&
                 text.indexOf("!") < 0)
            throw new IllegalArgumentException("illegal string");

        frequencies = new HashMap<String, List<Character>>();
        starts = new ArrayList<String>();
        r = new Random();
        starts.add(text.substring(0, n));
        for (int i = 0; i < text.length() - n; i++) {
            String current = text.substring(i, i + n);
            if (i >= 2 && ".?!".contains(text.substring(i - 2, i - 1)))
                starts.add(current);
            char ch = text.charAt(i + n);
            if (!frequencies.containsKey(current))
                frequencies.put(current, new ArrayList<Character>());
	    frequencies.get(current).add(ch);
        }
    }

    // if given string is part of the ngram inventory
    public boolean contains(String text) {
        return frequencies.containsKey(text);
    }

    // returns random character to follow given text
    public char randomChar(String text) {
        if (!contains(text))
            throw new IllegalArgumentException();
        return randomCharOf(frequencies.get(text));
    }

    private char randomCharOf(List<Character> s) {
        return s.get(r.nextInt(s.size()));
    }

    // returns random starting string
    public String randomStart() {
        return starts.get(r.nextInt(starts.size()));
    }
}
