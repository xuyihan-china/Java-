import java.util.*;

public class NgramSolver {
    private Map<String, StringBuilder> frequencies;
    private List<String> starts;
    private int n;
    private Random r;

    public NgramSolver(int n, String text) {
        if (n < 0 || n > text.length())
            throw new IllegalArgumentException("illegal n");
        else if (text.indexOf(".") < 0 && text.indexOf("?") < 0 &&
                 text.indexOf("!") < 0)
            throw new IllegalArgumentException("illegal string");

        this.n = n;
        frequencies = new HashMap<String, StringBuilder>();
        starts = new ArrayList<String>();
        r = new Random();
        starts.add(text.substring(0, n));
        for (int i = 0; i < text.length() - n; i++) {
            String current = text.substring(i, i + n);
            if (i >= 2 && ".?!".contains(text.substring(i - 2, i - 1)))
                starts.add(current);
            char ch = text.charAt(i + n);
            if (!frequencies.containsKey(current))
                frequencies.put(current, new StringBuilder("" + ch));
            else
		frequencies.get(current).append(ch);
        }
    }

    // if given string is part of the ngram inventory
    public boolean contains(String text) {
        return frequencies.containsKey(text);
    }

    // returns random character to follow given text
    public char randomChar(String text) {
        if (!contains(text))
            throw new IllegalArgumentException();
        return randomCharOf(frequencies.get(text));
    }

    private char randomCharOf(StringBuilder s) {
        return s.charAt(r.nextInt(s.length()));
    }

    // returns random starting string
    public String randomStart() {
        return starts.get(r.nextInt(starts.size()));
    }
}
